<?php // no direct access
/*
 * @licence GNI/GPLv3 https://www.gnu.org/licenses/gpl-3.0.html
 */
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<?php echo $quote; ?>
